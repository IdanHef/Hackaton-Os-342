﻿using System;
using System.Collections.Generic;
using System.Threading;

public class Consumer
{
    private static Mutex mutex = new Mutex();
    private static SemaphoreSlim empty = new SemaphoreSlim(0); // Start with no items consumed
    private static SemaphoreSlim full = new SemaphoreSlim(0); // Start with no items produced
    private Chair[] chairs;
    private bool isRunning;

    public Consumer(Chair[] chairs)
    {
        this.chairs = chairs;
        isRunning = true;
    }

    public void Consume()
    {
        while (isRunning)
        {
            mutex.WaitOne(); // Acquire the mutex to access the shared chairs

            full.Wait(); // Wait for a chair to be full

            Chair chair = FindTakenChair();

            // Modify the chair
            chair.pictureBox.Visible = false;
            chair.ReleaseChair();
            chair.ReleaseAnimal();

            Console.WriteLine($"Consumed from chair {chair.Id}");

            mutex.ReleaseMutex(); // Release the mutex

            empty.Release(); // Signal that a chair is empty and ready to be produced on

            // Check if the consumer should stop
            if (!isRunning)
            {
                break;
            }

            // Sleep for 1 second
            Thread.Sleep(1000);
        }
    }

    public void Stop()
    {
        isRunning = false;
    }

    private Chair FindTakenChair()
    {
        foreach (Chair chair in chairs)
        {
            if (chair.IsTaken)
            {
                return chair;
            }
        }

        return null; // Handle case when no taken chair is found (optional)
    }
}
