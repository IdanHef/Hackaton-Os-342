﻿using System;
using System.Collections.Generic;
using System.Threading;

public class Producer
{
    private static Mutex mutex = new Mutex();
    private static SemaphoreSlim empty = new SemaphoreSlim(90); // Maximum of 90 chairs
    private static SemaphoreSlim full = new SemaphoreSlim(0); // Start with no items produced
    private Chair[] chairs;
    private bool isRunning;

    public Producer(Chair[] chairs)
    {
        this.chairs = chairs;
        isRunning = true;
    }

    public void Produce()
    {
        while (isRunning)
        {
            mutex.WaitOne(); // Acquire the mutex to access the shared chairs

            empty.Wait(); // Wait for an empty chair

            Chair chair = FindAvailableChair();

            if (chair != null)
            {
                // Modify the chair
                chair.pictureBox.Visible = true;
                chair.TakeChair();
                chair.AssignAnimal();

                Console.WriteLine($"Produced on chair {chair.Id}");
            }

            mutex.ReleaseMutex(); // Release the mutex

            full.Release(); // Signal that a chair is full and ready to be consumed

            // Check if the producer should stop
            if (!isRunning)
            {
                break;
            }

            // Sleep for 1 second
            Thread.Sleep(1000);
        }
    }

    public void Stop()
    {
        isRunning = false;
    }

    private Chair FindAvailableChair()
    {
        foreach (Chair chair in chairs)
        {
            if (!chair.IsTaken)
            {
                return chair;
            }
        }

        return null; // Handle case when no available chair is found (optional)
    }
}
